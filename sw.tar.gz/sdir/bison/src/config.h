#define PACKAGE_BUGREPORT "http://sourceforge.net/p/winflexbison/tickets"
#define VERSION "3.4.1"
#define PACKAGE_COPYRIGHT_YEAR 2019
#define LOCALEDIR ""
#define PACKAGE_STRING "bison"
#define PACKAGE_URL "http://sourceforge.net/projects/winflexbison/"
#define PACKAGE ""
#define PACKAGE_VERSION "3.4.1"
#define PACKAGE_NAME "bison"
#define PKGDATADIR "data"
#define RENAME_OPEN_FILE_WORKS 1

#define ssize_t ptrdiff_t

extern char* _stpcpy(char *yydest, const char *yysrc);
